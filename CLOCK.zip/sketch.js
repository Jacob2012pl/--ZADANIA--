let button;
window.alert("NIE KLIKAJ NA ZEGAR!!!!!!!!")

function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
  textAlign(CENTER);
}
//wskazowki 1
function draw() {
  background('black');
  stroke('white');
  translate(width / 2, height / 2);
  wskazowki(second() * 6, 120, 2); //sekundy
  wskazowki(minute() * 6, 90, 4);  //minuty
  wskazowki((hour() % 12) * 30, 60, 4); //godziny
  Numery();
  circle(0, 0, 15);
//guzik
  button = createButton("");
  button.position(0,2000);
  window.open("https://egarnitur.pl/") // prawdziwy e-granitur
}
//wskazowki 2
function wskazowki(rotation, length, weight) {
  strokeWeight(weight);
  push();
  rotate(rotation);
  line(0, 0, 0, -length);
  pop();
}
//wskazowki 3
function Numery(){
  noStroke();
  fill('white');
  textSize(25);
  for (let i = 1; i <= 12; i++) {
    text(i,cos(i * 30 - 90) * 150,sin(i * 30 - 90) * 150 + 10);
  }
}

// By Jacob2012Pl2konto
